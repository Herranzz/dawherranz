# maquetacion-flexbox-sencilla

Una práctica de maquetación CSS basada en Flexbox. Este es el código completo del artículo [Maquetación con Flexbox](https://desarrolloweb.com/articulos/maquetacion-css-usando-flexbox).
